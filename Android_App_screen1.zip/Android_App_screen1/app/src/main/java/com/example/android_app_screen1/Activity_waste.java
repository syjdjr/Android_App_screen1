package com.example.android_app_screen1;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class Android_App_screen1_1 extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity);