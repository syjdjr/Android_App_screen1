package com.example.android_app_screen1;

public class linear {
}
